-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2019 at 08:26 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_motor`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_motor`
--

CREATE TABLE `data_motor` (
  `Tipe_motor` varchar(15) NOT NULL,
  `Harga` varchar(20) NOT NULL,
  `Uang_muka` varchar(20) NOT NULL,
  `Stok` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_motor`
--

INSERT INTO `data_motor` (`Tipe_motor`, `Harga`, `Uang_muka`, `Stok`) VALUES
('Absolute Revo', '14000000', '2200000', '9'),
('Beat', '15000000', '3000000', '19'),
('Blade', '17000000', '3000000', '14'),
('CB 150R', '25000000', '7000000', '8'),
('CBR 150R', '32000000', '11000000', '14'),
('Mega Pro', '22000000', '6000000', '9'),
('PCX', '41000000', '17000000', '4'),
('Scoopy', '17000000', '3000000', '19'),
('Sonic', '22000000', '6000000', '14'),
('Spacy', '15000000', '2500000', '15'),
('Supra X', '18000000', '3000000', '14'),
('Vario', '17000000', '3000000', '19'),
('Verza 150', '19000000', '4000000', '4');

-- --------------------------------------------------------

--
-- Table structure for table `data_pembeli`
--

CREATE TABLE `data_pembeli` (
  `Kode_pembeli` varchar(10) NOT NULL,
  `Nama_pembeli` varchar(20) NOT NULL,
  `NIK` varchar(20) NOT NULL,
  `Telepon` varchar(15) NOT NULL,
  `Alamat` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_pembeli`
--

INSERT INTO `data_pembeli` (`Kode_pembeli`, `Nama_pembeli`, `NIK`, `Telepon`, `Alamat`) VALUES
('B001', 'Baihirul Fuat', '1234567890123456', '081234567890', 'Duri Kosambi'),
('B0010', 'Amad Kurniadi', '1234567890696969', '081234567699', 'Kamal'),
('B0011', 'Hayabusa', '1234567890098765', '081234565432', 'Batu Ceper'),
('B0012', 'Zilong', '1234567893214567', '082234567812', 'Pesing'),
('B0013', 'Argus', '1234567812346537', '08123451265', 'Sunter'),
('B002', 'Angga Aji', '1234567890123455', '081234567899', 'Kayu Besar'),
('B003', 'Shantana', '1234567890123444', '081234567898', 'Roxy'),
('B004', 'Elfansyah', '1234567890123333', '081234567888', 'Kosambi'),
('B005', 'Siti Nurul Hidayah', '1234567890122222', '081234567777', 'Menceng'),
('B006', 'Harmono', '1234567890123654', '081234567777', 'Kapuk'),
('B007', 'Ahmad Nuryanto', '1234567890123890', '08112345678', 'Kapuk'),
('B008', 'Bagus Gradianto', '1234567890123469', '082345678911', 'Cipondoh'),
('B009', 'Ardi Riyanto', '1234567890123245', '081567893409', 'Taman Kota');

-- --------------------------------------------------------

--
-- Table structure for table `data_pengguna`
--

CREATE TABLE `data_pengguna` (
  `Nama_pengguna` varchar(20) NOT NULL,
  `Kata_sandi` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_pengguna`
--

INSERT INTO `data_pengguna` (`Nama_pengguna`, `Kata_sandi`) VALUES
('admin', '1234'),
('user', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `data_transaksi`
--

CREATE TABLE `data_transaksi` (
  `Id_transaksi` varchar(10) NOT NULL,
  `Tanggal_transaksi` date NOT NULL,
  `Kode_pembeli` varchar(10) NOT NULL,
  `Nama_pembeli` varchar(20) NOT NULL,
  `Tipe_motor` varchar(15) NOT NULL,
  `Harga` varchar(15) NOT NULL,
  `Stok` varchar(5) NOT NULL,
  `Jenis_bayar` varchar(10) NOT NULL,
  `Angsuran` varchar(10) NOT NULL,
  `Bunga` varchar(5) NOT NULL,
  `Uang_muka` varchar(15) NOT NULL,
  `Angsuran_per_bulan` varchar(15) NOT NULL,
  `Total_bayar` varchar(15) NOT NULL,
  `Sisa_stok` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_transaksi`
--

INSERT INTO `data_transaksi` (`Id_transaksi`, `Tanggal_transaksi`, `Kode_pembeli`, `Nama_pembeli`, `Tipe_motor`, `Harga`, `Stok`, `Jenis_bayar`, `Angsuran`, `Bunga`, `Uang_muka`, `Angsuran_per_bulan`, `Total_bayar`, `Sisa_stok`) VALUES
('TB001', '2017-11-01', 'B001', 'Baihirul Fuat', 'PCX', '41000000', '5', 'Tunai', 'Tidak ada', '0%', '0', '0', '41000000', '4'),
('TB0010', '2017-11-09', 'B0010', 'Amad Kurniadi', 'CB 150R', '25000000', '9', 'Kredit', '11 Kali', '5%', '7000000', '1750000', '7000000', '8'),
('TB0011', '2017-11-10', 'B0011', 'Hayabusa', 'Verza 150', '19000000', '5', 'Kredit', '11 Kali', '5%', '4000000', '1450000', '4000000', '4'),
('TB0012', '2017-11-13', 'B0012', 'Zilong', 'Supra X', '18000000', '15', 'Tunai', 'Tidak ada', '0%', '0', '0', '18000000', '14'),
('TB0014', '2019-09-19', 'B0013', 'Argus', 'Beat', '15000000', '15', 'Kredit', '35 Kali', '15%', '3000000', '407142', '3000000', '14'),
('TB0015', '2019-09-19', 'B001', 'Baihirul Fuat', 'Beat', '15000000', '20', 'Kredit', '11 Kali', '5%', '3000000', '1159090', '3000000', '19'),
('TB002', '2017-11-01', 'B002', 'Angga Aji', 'Vario', '17000000', '20', 'Tunai', 'Tidak ada', '0%', '0', '0', '17000000', '19'),
('TB003', '2017-11-02', 'B003', 'Shantana', 'Mega Pro', '22000000', '10', 'Tunai', 'Tidak ada', '0%', '0', '0', '22000000', '9'),
('TB004', '2017-11-03', 'B004', 'Elfansyah', 'Scoopy', '17000000', '20', 'Tunai', 'Tidak ada', '0%', '0', '0', '17000000', '19'),
('TB005', '2017-11-06', 'B005', 'Siti Nurul Hidayah', 'Beat', '15000000', '20', 'Tunai', 'Tidak ada', '0%', '0', '0', '15000000', '19'),
('TB006', '2017-11-06', 'B006', 'Harmono', 'Absolute Revo', '14000000', '10', 'Kredit', '35 Kali', '15%', '2200000', '397142', '2200000', '9'),
('TB007', '2017-11-07', 'B007', 'Ahmad Nuryanto', 'Blade', '17000000', '15', 'Kredit', '23 Kali', '10%', '3000000', '682608', '3000000', '14'),
('TB008', '2017-11-08', 'B008', 'Bagus Gradianto', 'Sonic', '22000000', '15', 'Tunai', 'Tidak ada', '0%', '0', '0', '22000000', '14'),
('TB009', '2017-11-09', 'B009', 'Ardi Riyanto', 'CB 150R', '25000000', '10', 'Tunai', 'Tidak ada', '0%', '0', '0', '25000000', '9');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_motor`
--
ALTER TABLE `data_motor`
  ADD PRIMARY KEY (`Tipe_motor`);

--
-- Indexes for table `data_pembeli`
--
ALTER TABLE `data_pembeli`
  ADD PRIMARY KEY (`Kode_pembeli`);

--
-- Indexes for table `data_pengguna`
--
ALTER TABLE `data_pengguna`
  ADD PRIMARY KEY (`Nama_pengguna`);

--
-- Indexes for table `data_transaksi`
--
ALTER TABLE `data_transaksi`
  ADD PRIMARY KEY (`Id_transaksi`),
  ADD KEY `Kode_pembeli` (`Kode_pembeli`),
  ADD KEY `Tipe_motor` (`Tipe_motor`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
