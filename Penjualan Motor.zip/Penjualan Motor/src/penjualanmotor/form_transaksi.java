 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualanmotor;

import com.mysql.jdbc.Statement;
import java.awt.HeadlessException;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.*;
import java.util.Date;
import java.util.logging.*;

/**
 *
 * @author ASUS
 */
public class form_transaksi extends javax.swing.JFrame {
String tanggal;

    /**
     * Creates new form penjualanmotor
     */    
    public form_transaksi() {
        initComponents();
        this.setLocationRelativeTo(null);
        datatable();
        combokode();
        combotipe();
    }
    
    
    private void datatable(){
    DefaultTableModel tbl = new DefaultTableModel();
    tbl.addColumn("ID Transaksi");
    tbl.addColumn("Tanggal Transaksi");
    tbl.addColumn("Kode Pembeli");
    tbl.addColumn("Nama Pembeli");
    tbl.addColumn("Tipe Motor");
    tbl.addColumn("Harga");
    tbl.addColumn("Stok");
    tbl.addColumn("Jenis Bayar");
    tbl.addColumn("Angsuran");
    tbl.addColumn("Bunga");
    tbl.addColumn("Uang Muka");
    tbl.addColumn("Angsuran Per Bulan");
    tbl.addColumn("Total Bayar");
    tbl.addColumn("Sisa Stok");
    tbTransaksi.setModel(tbl);
        try{
            Statement statement = (Statement) koneksi.getConnection().createStatement();
            ResultSet res = statement.executeQuery("Select * from data_transaksi order by length(Id_transaksi), Id_transaksi");
            while (res.next())
            {
                tbl.addRow(new Object []{
                    res.getString("Id_transaksi"),
                    res.getString("Tanggal_transaksi"),
                    res.getString("Kode_pembeli"),
                    res.getString("Nama_pembeli"),
                    res.getString("Tipe_motor"),
                    res.getString("Harga"),
                    res.getString("Stok"),
                    res.getString("Jenis_bayar"),
                    res.getString("Angsuran"),
                    res.getString("Bunga"),
                    res.getString("Uang_muka"),
                    res.getString("Angsuran_per_bulan"),
                    res.getString("Total_bayar"),
                    res.getString("Sisa_stok"),
                });
                tbTransaksi.setModel(tbl);
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog(rootPane, "Gagal");
        }
    }
    
    private String idtransaksi(){
        String no=null;
        try{
            koneksi.getConnection();
            Statement statement = (Statement) koneksi.getConnection().createStatement();
            ResultSet res = statement.executeQuery("Select right(Id_transaksi,3)+1 from data_transaksi order by length(Id_transaksi), Id_transaksi");
            if (res.next()){
            res.last();
            no = res.getString(1);
            while (no.length()<5){
            no="00"+no;
            no="TB"+no;
            tId.setText(no);
            }
        }else{
                no="TB001";
                tId.setText(no);
            }
        }catch (Exception e){
        }return no;
    }
    
    private void bersih(){
    setinput();
    tId.setText("");
    kTanggal.setDate(null);
    cKode.setSelectedItem("= PILIH =");
    tNama.setText("");
    cTipe.setSelectedItem("= PILIH =");
    tHarga.setText("");
    cJenisbayar.setSelectedItem("= PILIH =");
    cAngsuran.setSelectedItem("= PILIH =");
    tBunga.setText("");
    tUang.setText("");
    tAngsuran.setText("");
    tTotal.setText("");
    tStok.setText("");
    tSisa.setText("");
    tId.requestFocus();
    }
    
    private void simpan(){
    String Id_transaksi = tId.getText();
    String Tanggal_transaksi = kTanggal.getDateFormatString();
    String Kode_pembeli = cKode.getSelectedItem().toString();
    String Nama_pembeli = tNama.getText();
    String Tipe_motor = cTipe.getSelectedItem().toString();
    String Harga = tHarga.getText();
    String Stok = tStok.getText();
    String Jenis_bayar = cJenisbayar.getSelectedItem().toString();
    String Angsuran = cAngsuran.getSelectedItem().toString();
    String Bunga = tBunga.getText();
    String Uang_muka = tUang.getText();
    String Angsuran_per_bulan = tAngsuran.getText();
    String Total_bayar = tTotal.getText();
    String Sisa_stok = tSisa.getText();
    try{
        Statement statement = (Statement) koneksi.getConnection().createStatement();
        statement.executeUpdate("insert into data_transaksi VALUES ('"+Id_transaksi+"','"+tanggal+"','"+Kode_pembeli+"','"+Nama_pembeli+"','"+Tipe_motor+"','"+Harga+"','"+Stok+"','"+Jenis_bayar+"','"+Angsuran+"','"+Bunga+"','"+Uang_muka+"','"+Angsuran_per_bulan+"','"+Total_bayar+"','"+Sisa_stok+"')");
        statement.executeUpdate("update data_motor set Tipe_motor='"+Tipe_motor+"',"+"Stok='"+Sisa_stok+"' "+" where Tipe_motor='"+Tipe_motor+"'");
        statement.close();
        JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
        bersih();
    }catch (Exception e){
        JOptionPane.showMessageDialog(null, "Data Gagal Disimpan " +e);
    }
    datatable();
    }
    
    private void edit(){
    String Id_transaksi = tId.getText();
    String Tanggal_transaksi = kTanggal.getDateFormatString();
    String Kode_pembeli = cKode.getSelectedItem().toString();
    String Nama_pembeli = tNama.getText();
    String Tipe_motor = cTipe.getSelectedItem().toString();
    String Harga = tHarga.getText();
    String Stok = tStok.getText();
    String Jenis_bayar = cJenisbayar.getSelectedItem().toString();
    String Angsuran = cAngsuran.getSelectedItem().toString();
    String Bunga = tBunga.getText();
    String Uang_muka = tUang.getText();
    String Angsuran_per_bulan = tAngsuran.getText();
    String Total_bayar = tTotal.getText();
    String Sisa_stok = tSisa.getText();
    try{
        Statement statement = (Statement) koneksi.getConnection().createStatement();
        statement.executeUpdate("update data_transaksi SET Id_transaksi='"+Id_transaksi+"',"+"Tanggal_transaksi='"+tanggal+"',"+"Kode_pembeli='"+Kode_pembeli+"',"+"Nama_pembeli='"+Nama_pembeli+"',"+"Tipe_motor='"+Tipe_motor+"',"+"Harga='"+Harga+"',"+"Stok='"+Stok+"',"+"Jenis_bayar='"+Jenis_bayar+"',"+"Angsuran='"+Angsuran+"',"+"Bunga='"+Bunga+"',"+"Uang_muka='"+Uang_muka+"',"+"Angsuran_per_bulan='"+Angsuran_per_bulan+"',"+"Total_bayar='"+Total_bayar+"',"+"Sisa_stok='"+Sisa_stok+"'" + "WHERE Id_transaksi= '"+Id_transaksi+"'" + "OR Nama_pembeli= '"+Nama_pembeli+"'");
        statement.executeUpdate("update data_motor set Tipe_motor='"+Tipe_motor+"',"+"Stok='"+Sisa_stok+"' "+" where Tipe_motor='"+Tipe_motor+"'");
        statement.close();
        JOptionPane.showMessageDialog(null, "Data Berhasil di Edit");
        bersih();
    }catch (Exception t){
        JOptionPane.showMessageDialog(null, "Data Gagal di Edit");
    }
    datatable();
    }
    
    private void hapus(){
    if(JOptionPane.showConfirmDialog(this,"Yakin ingin menghapus data?","Konfirmasi",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
    String Id_transaksi = tId.getText();
    String Kode_pembeli = cKode.getSelectedItem().toString();
    try{
        Statement statement = (Statement) koneksi.getConnection().createStatement();
        statement.executeUpdate("delete from data_transaksi where Id_transaksi='"+Id_transaksi+"';");
        JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
        bersih();
    }catch (Exception t){
        JOptionPane.showMessageDialog(null, "Data Gagal Dihapus");
    }
    }
    datatable();
    }
    
    private void combokode(){
    cKode.addItem("= PILIH =");
    cKode.setSelectedItem("= PILIH =");
    try {
        Statement statement = (Statement) koneksi.getConnection().createStatement();
        String sql = "select * from data_pembeli order by length(Kode_pembeli), Kode_pembeli";
        ResultSet res = statement.executeQuery(sql);
        while (res.next()) {
        cKode.addItem(res.getString("Kode_pembeli"));
        }
        res.close();
        statement.close();
        }catch (Exception e) {
        JOptionPane.showMessageDialog(null,"Terjadi Kesalahan");
        }
    }
    
    private void tampilkode(){
    String kode=cKode.getSelectedItem().toString();
    String sql="select* from data_pembeli where Kode_pembeli='"+kode+"'";
    try{
        Statement statement = (Statement) koneksi.getConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);
        while(res.next()){
            tNama.setText(res.getString("Nama_pembeli"));
            }
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Terjadi Kesalahan");
        }
    }
        
    private void combotipe(){
    cTipe.addItem("= PILIH =");
    cTipe.setSelectedItem("= PILIH =");
    try {
        Statement statement = (Statement) koneksi.getConnection().createStatement();
        String sql = "select * from data_motor";
        ResultSet res = statement.executeQuery(sql);
        while (res.next()) {
        cTipe.addItem(res.getString("Tipe_motor"));
        }
        res.close();
        statement.close();
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Terjadi Kesalahan");
        }
    }
    
    private void tampiltipe(){
    String tipe=cTipe.getSelectedItem().toString();
    String sql="select* from data_motor where Tipe_motor='"+tipe+"'";
    try{
        Statement statement = (Statement) koneksi.getConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);
        while(res.next()){
            tStok.setText(res.getString("Stok"));
            tHarga.setText(res.getString("Harga"));
            }
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Terjadi Kesalahan");
        }
    }
    
    private void combojenis(){
    if (cJenisbayar.getSelectedItem().equals("Tunai")){
    cAngsuran.setSelectedItem("Tidak ada");
    cAngsuran.setEnabled(false);
    bAngsuran.setEnabled(false);
    tBunga.setText("0%");
    tUang.setText("0");
    tAngsuran.setText("0");
    tTotal.setText("");
    }
    else if (cJenisbayar.getSelectedItem().equals("Kredit")){
    cAngsuran.setEnabled(true);
    bAngsuran.setEnabled(true);
    cAngsuran.setSelectedItem("= PILIH =");
    tAngsuran.setText("");
    tTotal.setText("");
    String tipe=cTipe.getSelectedItem().toString();
    String sql="select* from data_motor where Tipe_motor='"+tipe+"'";
    try{
        Statement statement = (Statement) koneksi.getConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);
        while(res.next()){
            tUang.setText(res.getString("Uang_muka"));
            }
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Terjadi Kesalahan");
        }
    }
    }
    
    private void infotabel(){
        int i = tbTransaksi.getSelectedRow();
    if (i==-1){
        return;
    }
    try{
    String Id_transaksi = (String) tbTransaksi.getValueAt(i, 0);
    tId.setText(Id_transaksi);
    Date Tanggal_transaksi = new SimpleDateFormat("yyyy-MM-dd").parse((String)tbTransaksi.getValueAt(i, 1));
    kTanggal.setDate(Tanggal_transaksi);
    String Kode_pembeli = (String) tbTransaksi.getValueAt(i, 2);
    cKode.setSelectedItem(Kode_pembeli);
    String Tipe_motor = (String) tbTransaksi.getValueAt(i, 4);
    cTipe.setSelectedItem(Tipe_motor);
    String Stok = (String) tbTransaksi.getValueAt(i, 6);
    tStok.setText(Stok);
    String Jenis_bayar = (String) tbTransaksi.getValueAt(i, 7);
    cJenisbayar.setSelectedItem(Jenis_bayar);
    String Angsuran = (String) tbTransaksi.getValueAt(i, 8);
    cAngsuran.setSelectedItem(Angsuran);
    String Uang_muka = (String) tbTransaksi.getValueAt(i, 10);
    tUang.setText(Uang_muka);
    String Angsuran_per_bulan = (String) tbTransaksi.getValueAt(i, 11);
    tAngsuran.setText(Angsuran_per_bulan);
    String Total_bayar = (String) tbTransaksi.getValueAt(i, 12);
    tTotal.setText(Total_bayar);
    String Sisa_stok = (String) tbTransaksi.getValueAt(i, 13);
    tSisa.setText(Sisa_stok);
    }catch (ParseException ex) {
            Logger.getLogger(form_transaksi.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void sisastok(){
    long nStok,nSisa;
    nStok=Long.parseLong(tStok.getText());
    nSisa=nStok-1;
    tSisa.setText(String.valueOf(nSisa));
    }
    
    private void setinput(){
    tHarga.setEditable(false);
    tNama.setEditable(false);
    tBunga.setEditable(false);
    tUang.setEditable(false);
    tAngsuran.setEditable(false);
    tTotal.setEditable(false);
    tSisa.setEditable(false);
    tId.requestFocus();
    }
    
    private void aktif(){
    tId.setEnabled(true);
    kTanggal.setEnabled(true);
    cKode.setEnabled(true);
    tNama.setEnabled(true);
    cTipe.setEnabled(true);
    tHarga.setEnabled(true);
    cJenisbayar.setEnabled(true);
    cAngsuran.setEnabled(true);
    tBunga.setEnabled(true);
    tUang.setEnabled(true);
    tAngsuran.setEnabled(true);
    tTotal.setEnabled(true);
    tStok.setEnabled(true);
    tSisa.setEnabled(true);
    }
    
    private void nonaktif(){
    tId.setEnabled(false);
    kTanggal.setEnabled(false);
    cKode.setEnabled(false);
    tNama.setEnabled(false);
    cTipe.setEnabled(false);
    tHarga.setEnabled(false);
    cJenisbayar.setEnabled(false);
    cAngsuran.setEnabled(false);
    tBunga.setEnabled(false);
    tUang.setEnabled(false);
    tAngsuran.setEnabled(false);
    tTotal.setEnabled(false);
    tStok.setEnabled(false);
    tSisa.setEnabled(false);
    bBatal.setEnabled(false);
    bSimpan.setEnabled(false);
    bEdit.setEnabled(false);
    bHapus.setEnabled(false);
    bAngsuran.setEnabled(false);
    bTotal.setEnabled(false);
    }
       
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        tHarga = new javax.swing.JTextField();
        cJenisbayar = new javax.swing.JComboBox<>();
        cAngsuran = new javax.swing.JComboBox<>();
        tBunga = new javax.swing.JTextField();
        tTotal = new javax.swing.JTextField();
        tAngsuran = new javax.swing.JTextField();
        bTotal = new javax.swing.JToggleButton();
        bAngsuran = new javax.swing.JToggleButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        cTipe = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        cKode = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        tId = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        tNama = new javax.swing.JTextField();
        tUang = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        kTanggal = new com.toedter.calendar.JDateChooser();
        jLabel15 = new javax.swing.JLabel();
        tStok = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        tSisa = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        bEdit = new javax.swing.JButton();
        bHapus = new javax.swing.JButton();
        bKeluar = new javax.swing.JButton();
        bTambah = new javax.swing.JButton();
        bBatal = new javax.swing.JButton();
        bSimpan = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbTransaksi = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Transaksi");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 153, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setPreferredSize(new java.awt.Dimension(786, 70));

        jLabel1.setBackground(new java.awt.Color(0, 102, 51));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("DATA TRANSAKSI");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(200, 200, 200)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(200, 200, 200))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(0, 153, 102));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        cJenisbayar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "= PILIH =", "Tunai", "Kredit" }));
        cJenisbayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cJenisbayarActionPerformed(evt);
            }
        });

        cAngsuran.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "= PILIH =", "11 Kali", "23 Kali", "35 Kali", "Tidak ada" }));
        cAngsuran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cAngsuranActionPerformed(evt);
            }
        });

        bTotal.setText("Hitung");
        bTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTotalActionPerformed(evt);
            }
        });

        bAngsuran.setText("Hitung");
        bAngsuran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAngsuranActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel4.setText("Tipe Motor");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel5.setText("Harga");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel6.setText("Jenis Bayar");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel7.setText("Angsuran");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel8.setText("Bunga");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel9.setText("Total Bayar");

        jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel10.setText("Angsuran Per Bulan");

        cTipe.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cTipeItemStateChanged(evt);
            }
        });
        cTipe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cTipeActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel3.setText("Uang Muka");

        jLabel11.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel11.setText("Kode Pembeli");

        cKode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cKodeActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel12.setText("ID Transaksi");

        jLabel13.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel13.setText("Nama Pembeli");

        jLabel14.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel14.setText("Tanggal Transaksi");

        kTanggal.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                kTanggalPropertyChange(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel15.setText("Stok");

        jLabel16.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel16.setText("Sisa Stok");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addComponent(tId, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(71, 71, 71)
                        .addComponent(cKode, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(71, 71, 71)
                        .addComponent(tNama, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(88, 88, 88)
                        .addComponent(cTipe, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(48, 48, 48)
                        .addComponent(kTanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel15))
                        .addGap(119, 119, 119)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tStok, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 122, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(88, 88, 88)
                        .addComponent(cJenisbayar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(98, 98, 98)
                        .addComponent(cAngsuran, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(117, 117, 117)
                        .addComponent(tBunga, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(87, 87, 87)
                        .addComponent(tUang, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(40, 40, 40)
                        .addComponent(tAngsuran, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(bAngsuran, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(tSisa, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(87, 87, 87)
                                .addComponent(tTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(6, 6, 6)
                        .addComponent(bTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(tId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel6))
                    .addComponent(cJenisbayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel14))
                    .addComponent(kTanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel7))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(cAngsuran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel11))
                    .addComponent(cKode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel8))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(tBunga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel13))
                    .addComponent(tNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel3))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(tUang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel4))
                    .addComponent(cTipe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel10))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(tAngsuran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(bAngsuran)))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel5))
                    .addComponent(tHarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel9))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(tTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(bTotal))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(tStok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(tSisa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(0, 153, 102));
        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        bEdit.setText("Edit");
        bEdit.setPreferredSize(new java.awt.Dimension(60, 23));
        bEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEditActionPerformed(evt);
            }
        });

        bHapus.setText("Hapus");
        bHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bHapusActionPerformed(evt);
            }
        });

        bKeluar.setText("Keluar");
        bKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bKeluarActionPerformed(evt);
            }
        });

        bTambah.setText("Tambah");
        bTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTambahActionPerformed(evt);
            }
        });

        bBatal.setText("Batal");
        bBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBatalActionPerformed(evt);
            }
        });

        bSimpan.setText("Simpan");
        bSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSimpanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(184, 184, 184)
                .addComponent(bTambah, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bSimpan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bEdit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bBatal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bHapus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bKeluar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap(189, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(bSimpan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bEdit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bHapus)
                        .addComponent(bKeluar)
                        .addComponent(bTambah)
                        .addComponent(bBatal)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(0, 153, 102));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tbTransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbTransaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbTransaksiMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbTransaksi);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 838, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cTipeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cTipeActionPerformed
    tampiltipe();
    if (cTipe.getSelectedItem().equals("= PILIH =")){
        tHarga.setText("");
        tStok.setText("");
        cJenisbayar.setSelectedItem("= PILIH =");
        cAngsuran.setSelectedItem("= PILIH =");
        tBunga.setText("");
        tUang.setText("");
    }
    }//GEN-LAST:event_cTipeActionPerformed

    private void cAngsuranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cAngsuranActionPerformed
    if (cAngsuran.getSelectedItem().equals("= PILIH =")){
        tBunga.setText("");
        tUang.setText("");
    }
    else if (cAngsuran.getSelectedItem().equals("11 Kali")){
    tBunga.setText("5%");
    }
    else if (cAngsuran.getSelectedItem().equals("23 Kali")){
    tBunga.setText("10%");
    }
    else if (cAngsuran.getSelectedItem().equals("35 Kali")){
    tBunga.setText("15%");
    }
    }//GEN-LAST:event_cAngsuranActionPerformed

    private void cJenisbayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cJenisbayarActionPerformed
    combojenis();
    if (cJenisbayar.getSelectedItem().equals("= PILIH =")){
        cAngsuran.setSelectedItem("= PILIH =");
        tBunga.setText("");
        tUang.setText("");
        tAngsuran.setText("");
        tTotal.setText("");
        tSisa.setText("");
    }
    }//GEN-LAST:event_cJenisbayarActionPerformed

    private void cKodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cKodeActionPerformed
    tampilkode();
    if (cKode.getSelectedItem().equals("= PILIH =")){
        tNama.setText("");
    }
    }//GEN-LAST:event_cKodeActionPerformed

    private void kTanggalPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_kTanggalPropertyChange
    if (kTanggal.getDate()!=null){
SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
tanggal = simpleDateFormat.format(kTanggal.getDate());
}
    }//GEN-LAST:event_kTanggalPropertyChange

    private void bSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSimpanActionPerformed
    simpan();
    bTambah.setEnabled(true);
    bKeluar.setEnabled(true);
    }//GEN-LAST:event_bSimpanActionPerformed

    private void bEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEditActionPerformed
    edit();
    bTambah.setEnabled(true);
    }//GEN-LAST:event_bEditActionPerformed

    private void bHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bHapusActionPerformed
    hapus();
    nonaktif();
    bersih();
    bTambah.setEnabled(true);
    }//GEN-LAST:event_bHapusActionPerformed

    private void bKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bKeluarActionPerformed
    dispose();
    }//GEN-LAST:event_bKeluarActionPerformed

    private void bAngsuranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAngsuranActionPerformed
    try{
        long nHarga,nBunga,nMuka,nAngsur,nAngsurperbulan;
        nHarga=Long.parseLong(tHarga.getText());
        nBunga=Long.parseLong(tBunga.getText().replace("%",""));
        nMuka=Long.parseLong(tUang.getText());
        nAngsur=Long.parseLong(cAngsuran.getSelectedItem().toString().substring(0,2));
        nAngsurperbulan=(nHarga*nBunga/100+nHarga-nMuka)/(nAngsur);
        tAngsuran.setText(String.valueOf(nAngsurperbulan));
    }catch(Exception e) {
            JOptionPane.showMessageDialog(null,"Error!!! Pastikan semua data sudah diisi dengan benar!");
        }
    }//GEN-LAST:event_bAngsuranActionPerformed

    private void bTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTotalActionPerformed
    sisastok();
    if (cJenisbayar.getSelectedItem().equals("Tunai")){
    tTotal.setText(tHarga.getText());
    }
    else if (cJenisbayar.getSelectedItem().equals("Kredit")){
    tTotal.setText(tUang.getText());
    }
    }//GEN-LAST:event_bTotalActionPerformed

    private void tbTransaksiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbTransaksiMouseClicked
    infotabel();
    aktif();
    bAngsuran.setEnabled(true);
    bTotal.setEnabled(true);
    bHapus.setEnabled(true);
    bBatal.setEnabled(true);
    bEdit.setEnabled(true);
    bTambah.setEnabled(false);
    }//GEN-LAST:event_tbTransaksiMouseClicked

    private void bTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTambahActionPerformed
    bersih();
    idtransaksi();
    aktif();
    bTambah.setEnabled(false);
    bBatal.setEnabled(true);
    bSimpan.setEnabled(true);
    bAngsuran.setEnabled(true);
    bTotal.setEnabled(true);
    }//GEN-LAST:event_bTambahActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
    bersih();
    nonaktif();
    }//GEN-LAST:event_formWindowActivated

    private void cTipeItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cTipeItemStateChanged
        tHarga.setText("");
        tStok.setText("");
        cJenisbayar.setSelectedItem("= PILIH =");
        cAngsuran.setSelectedItem("= PILIH =");
        tBunga.setText("");
        tUang.setText("");
        tTotal.setText("");
        tSisa.setText("");
    }//GEN-LAST:event_cTipeItemStateChanged

    private void bBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBatalActionPerformed
    nonaktif();
    bersih();
    bTambah.setEnabled(true);
    }//GEN-LAST:event_bBatalActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(form_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(form_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(form_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(form_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new form_transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton bAngsuran;
    private javax.swing.JButton bBatal;
    private javax.swing.JButton bEdit;
    private javax.swing.JButton bHapus;
    private javax.swing.JButton bKeluar;
    private javax.swing.JButton bSimpan;
    private javax.swing.JButton bTambah;
    private javax.swing.JToggleButton bTotal;
    private javax.swing.JComboBox<String> cAngsuran;
    private javax.swing.JComboBox<String> cJenisbayar;
    private javax.swing.JComboBox<String> cKode;
    private javax.swing.JComboBox<String> cTipe;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private com.toedter.calendar.JDateChooser kTanggal;
    private javax.swing.JTextField tAngsuran;
    private javax.swing.JTextField tBunga;
    private javax.swing.JTextField tHarga;
    private javax.swing.JTextField tId;
    private javax.swing.JTextField tNama;
    private javax.swing.JTextField tSisa;
    private javax.swing.JTextField tStok;
    private javax.swing.JTextField tTotal;
    private javax.swing.JTextField tUang;
    private javax.swing.JTable tbTransaksi;
    // End of variables declaration//GEN-END:variables
}
