/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualanmotor;
import java.awt.*;
import javax.swing.*;
/**
 *
 * @author Baihirul Fuat
 */
public class background extends JPanel {
    Image gambar1;
    public background(){
        gambar1 = new ImageIcon(getClass().getResource("/penjualanmotor/bg_menu.jpg")).getImage();
    }
    
   @Override
   protected void paintComponent(Graphics g){
       super.paintComponent(g);
       Graphics2D gd = (Graphics2D)g.create();
       gd.drawImage(gambar1, 0,0, getWidth(),getHeight(),null);
       gd.dispose();
   }
}
